# Online-Examination-System
Examination System with inbuilt result analysis feature.Built with HTML,CSS,JavaScript,PHP,MySQL,Bootstrap,JQuery,AJAX.
